"""Utilities for segmentation processors"""

import logging
from itertools import chain, islice


def batch(iterable, size):
    """Make iterable over packages of a certain size

    Args:
        iterable (_type_): source iterable
        size (_type_): size of the batches

    Yields:
        _type_: iterable over individual batches
    """

    sourceiter = iter(iterable)
    while True:
        batchiter = islice(sourceiter, size)
        try:
            logging.debug("Next batch...")
            # get first element to known when iterator is at end (will throw StopIteration)
            first_element = next(batchiter)
            if size == 1:
                # single sized batches shall also be lists
                yield [first_element]
            else:
                # chain longer batches
                yield chain([first_element], batchiter)
        except StopIteration:
            # we have reached the end of the iterator
            # --> leave loop
            return


class ModelDescriptor:
    """Describing all parameters to run a segmentation model from a git repository"""

    def __init__(self, repo: str, entry_point: str, version: str, parameters=None):
        if parameters is None:
            parameters = {}

        self.repo = repo
        self.entry_point = entry_point
        self.version = version
        self.parameters = parameters


class RemoteExecutor:
    """Properties for remote segmentation execution"""

    def __init__(self, url: str, timeout: int = 600):
        self.url = url
        self.timeout = timeout
