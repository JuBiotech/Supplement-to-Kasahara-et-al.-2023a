"""Offline segmentation model execution"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from tempfile import TemporaryDirectory

import cv2
import mlflow
import numpy as np
import tqdm
from furl import furl

from acia.base import Contour, ImageSequenceSource, Overlay, Processor

from .utils import ModelDescriptor, batch


class FlexibleOfflineModel(Processor):
    """
    The model is not running locally on the computer but in a remote location
    """

    def __init__(self, modelDesc: ModelDescriptor, batch_size=1):
        self.modelDesc = modelDesc
        self.batch_size = batch_size

    def predict(self, source: ImageSequenceSource, params=None):
        if params is None:
            params = {}

        contours = []

        # Segmentation method parameters
        additional_parameters = dict(self.modelDesc.parameters)
        additional_parameters.update(**params)

        # http request parameters
        params = dict(
            repo=self.modelDesc.repo,
            entry_point=self.modelDesc.entry_point,
            version=self.modelDesc.version,
            parameters=additional_parameters,
        )

        # Do batch prediction
        for local_batch in batch(enumerate(tqdm.tqdm(source)), self.batch_size):
            local_batch = np.array(list(local_batch), dtype=object)

            frames = local_batch[:, 0]
            images = map(lambda img: img.raw, local_batch[:, 1])

            contours += self.predict_batch(frames, images, params)

        for i, cont in enumerate(contours):
            cont.id = i

        # create new overlay based on all contours
        return Overlay(contours)

    @staticmethod
    def predict_batch(frame_ids: list[int], images: list, params: dict) -> Overlay:
        """Predict segmentation for a batch of frames

        Args:
            frame_ids (List[int]): ids of the frames
            images (List): numpy array for every image
            params ([type]): dictionary of additional parameters

        Raises:
            ValueError: [description]

        Returns:
            [Overlay]: An overlay containing the segmentation information for the images
        """
        contours = []

        # write images to temp folder
        with TemporaryDirectory() as tmpDir:

            image_paths = []
            output_file = Path(tmpDir) / "output.json"
            image_folder = Path(tmpDir) / "images"
            os.makedirs(image_folder)

            for i, file in enumerate(images):
                # write image file
                input_file = image_folder / f"{i:03d}.png"

                image_paths.append(input_file.absolute())

                cv2.imwrite(str(input_file), file)

            additional_parameters = {}
            if "parameters" in params:
                additional_parameters = params["parameters"]

            repo = params["repo"]
            entry_point = params["entry_point"]
            version = params["version"]

            # execute the project
            current_time = time.time()
            run = mlflow.projects.run(
                repo,
                entry_point=entry_point,
                version=version,
                backend="local",
                storage_dir=tmpDir,
                parameters={"input_images": str(image_folder), **additional_parameters},
            )

            # notify segmentation time
            duration = time.time() - current_time

            # make a password less repo url for logging
            parsed = furl(repo)
            parsed.password = ""
            parsed.username = ""
            repo_safe = parsed.url

            logging.info(
                "Segmentaiton (repo: %s, entry_point: %s, version: %s, parameters:%s) took: %.3f seconds",
                repo_safe,
                entry_point,
                version,
                additional_parameters,
                duration,
            )

            # download the output artifact
            client = mlflow.tracking.MlflowClient()
            client.download_artifacts(run.run_id, "output.json", output_file.parent)

            if not Path(output_file).is_file():
                raise FileNotFoundError(
                    "Could not find \"output.json\" file. Please log this as an artifact in your code: mlflow.log_artifact('output.json')"
                )

            # collect the results
            with open(output_file, encoding="utf-8") as output_json:
                result = json.load(output_json)

                for i, frame_id in enumerate(frame_ids):
                    content = result["segmentation_data"][i]
                    for detection in content:
                        # label = detection['label']
                        contour = np.array(
                            detection["contour_coordinates"], dtype=np.float32
                        )
                        score = -1.0

                        contours.append(Contour(contour, score, frame_id, -1))

                return Overlay(contours, frame_ids)
