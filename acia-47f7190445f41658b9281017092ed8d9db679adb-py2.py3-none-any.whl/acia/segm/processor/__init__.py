"""Processors for image segmentation"""

from __future__ import annotations

from acia.base import ImageSequenceSource, Overlay, Processor

from .offline import FlexibleOfflineModel
from .online import FlexibleOnlineModel
from .utils import ModelDescriptor, RemoteExecutor


class FlexibleSegmentationModel(Processor):
    """
    General definition of a segmentation model that can run offline or online
    """

    def __init__(
        self,
        modelDesc: ModelDescriptor,
        batch_size=1,
        remote_executor: RemoteExecutor = None,
    ):
        self.modelDesc = modelDesc
        self.batch_size = batch_size
        self.remote_executor = remote_executor

        if remote_executor:
            self.interal_model = FlexibleOnlineModel(
                remote_executor.url, modelDesc, remote_executor.timeout, batch_size
            )
        else:
            self.interal_model = FlexibleOfflineModel(modelDesc, batch_size)

    def predict(self, source: ImageSequenceSource, params=None) -> Overlay:
        return self.interal_model.predict(source, params)
